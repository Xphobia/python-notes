
import sys
from pycomm3 import LogixDriver
import pysnooper

import CipClient_UI
from PyQt5.QtCore import (
    qDebug,
)
from PyQt5 import QtWidgets
from PyQt5.QtGui import QIcon
from PyQt5.QtWidgets import (
    QApplication,
)


class CipClient(QtWidgets.QMainWindow):
    def __init__(self, name='CipClient'):
        super().__init__()
        self.initUI(name)

    def initUI(self, name):
        self.ui = CipClient_UI.Ui_MainWindow()
        self.ui.setupUi(self)
        self.setWindowTitle(name)
        # self.setWindowIcon(QIcon('cip.png'))
        # self.setStyleSheet('background-color: green')

    @pysnooper.snoop('test.log')
    def plcConnectTest(self):
        ip = self.ui.lineEditIP.text()
        port = self.ui.lineEditPort.text()
        msg = 'ip: %s, port: %s' % (ip, port)

        try:
            ip += '/1'
            with LogixDriver(ip) as plc:
                msg = plc.info
        except Exception as e:
            msg = "Exception: %s" % str(e)
        else:
            msg = 'connect to plc successfully'

        self.ui.plainTextEditOutput.clear()
        self.ui.plainTextEditOutput.appendPlainText(msg)

    @pysnooper.snoop('read.log')
    def plcReadTag(self):
        ip = self.ui.lineEditIP.text()
        tag = self.ui.lineEditReadTagName()

        try:
            ip += '/1'
            with LogixDriver(ip) as plc:
                result = plc.read(tag)
                if result.error:
                    msg = 'read plc tag failed'
                self.ui.lineEditReadTagValue.clear()
                self.ui.lineEditReadTagValue.setText(result)
        except Exception as e:
            msg = "Exception: %s" % str(e)
        else:
            msg = 'read plc tag successfully'

        self.ui.plainTextEditOutput.clear()
        self.ui.plainTextEditOutput.appendPlainText(msg)

    @pysnooper.snoop('write.log')
    def plcWriteTag(self):
        ip = self.ui.lineEditIP.text()
        tag = self.ui.lineEditReadTagName()
        value = self.ui.lineEditWriteTagValue()

        try:
            ip += '/1'
            with LogixDriver(ip) as plc:
                result = plc.write(tag, value)
                if result.error:
                    msg = 'write plc tag failed'
        except Exception as e:
            msg = "Exception: %s" % str(e)
        else:
            msg = 'write plc tag successfully'

        self.ui.plainTextEditOutput.clear()
        self.ui.plainTextEditOutput.appendPlainText(msg)


if __name__ == '__main__':
    app = QApplication(sys.argv)
    client = CipClient()
    client.show()
    sys.exit(app.exec_())

